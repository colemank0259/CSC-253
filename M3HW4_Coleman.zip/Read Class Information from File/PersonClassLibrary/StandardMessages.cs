﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonClassLibrary
{
    public class StandardMessages
    {
        public string PromptInfo
        {
            get
            {
                return "This program will load data from a file and create a" +
                    "class object, then display that object's info to the user.";
            }
        }
    }
}
