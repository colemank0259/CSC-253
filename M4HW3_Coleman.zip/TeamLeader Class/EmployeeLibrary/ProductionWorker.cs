﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class ProductionWorker : Employee
    {
        // Constructor
        public ProductionWorker (string employeeName, int employeeNumber, 
            int shiftNumber, decimal hourlyPay) : base (employeeName, employeeNumber)
        {
            ShiftNumber = shiftNumber;
            HourlyPay = hourlyPay;
        }

        // ShiftNumber property
        public int ShiftNumber { get; set; }

        // HourlyPay property
        public decimal HourlyPay { get; set; }
    }
}
