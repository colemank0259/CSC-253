﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class TeamLeader : ProductionWorker
    {
        // Constructor
        public TeamLeader(string employeeName, int employeeNumber,
            int shiftNumber, decimal hourlyPay, decimal monthlyBonus, 
            int requiredTrainingHours, int completedTrainingHours) 
            : base(employeeName, employeeNumber, shiftNumber, hourlyPay)
        {
            MonthlyBonus = monthlyBonus;
            RequiredTrainingHours = requiredTrainingHours;
            CompletedTrainingHours = completedTrainingHours;
        }

        // MonthlyBonus property
        public decimal MonthlyBonus { get; set; }

        // RequiredTrainingHours property
        public int RequiredTrainingHours { get; set; }

        // CompletedTrainingHours property
        public int CompletedTrainingHours { get; set; }
    }
}
