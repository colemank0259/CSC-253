﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLibrary;
/**
* 10/31/19
* CSC 253
* Kevin Coleman
* This program collects and displays production team leader information.
*/
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            // Local variables
            string inputString = null;
            TeamLeader myWorker = new TeamLeader(null, 0, 0, 0m, 0m, 0, 0);
            bool run = true;

            // Dispaly the program description to the user.
            Console.WriteLine("This program collects and displays production team leader information.");

            do
            {
                // Consume the next line for appearance
                Console.WriteLine("");

                // Display the main menu
                Console.WriteLine("1. Add and display a new production worker");
                Console.WriteLine("2. Exit");

                // Get the user's input to select an option.
                Console.Write("Enter a number to select an option: ");
                inputString = Console.ReadLine();

                // Consume the next line for appearance
                Console.WriteLine("");

                // Execute the program
                switch (inputString)
                {
                    case "1":
                        myWorker = GetTeamLeader(myWorker);
                        DisplayTeamLeader(myWorker);
                        break;
                    case "2":
                        run = false;
                        break;
                    default:
                        Console.WriteLine("ERROR: You must enter 1 or 2 to select an action.");
                        break;
                }
            } while (run == true);

        }

        static TeamLeader GetTeamLeader(TeamLeader myWorker)
        {
            // Local variables
            string input = null;

            // Get the worker's name
            Console.Write("Enter the worker's name: ");
            myWorker.EmployeeName = Console.ReadLine();

            // Consume the next line for appearance
            Console.WriteLine("");

            // Get the worker's employee number
            Console.Write("Enter the worker's employee number: ");
            myWorker.EmployeeNumber = int.Parse(Console.ReadLine());

            // Consume the next line for appearance
            Console.WriteLine("");

            // Get the worker's shift number
            myWorker.ShiftNumber = GetShiftNumber();

            // Consume the next line for appearance
            Console.WriteLine("");

            // Get the worker's hourly pay rate
            Console.Write("Enter the worker's hourly pay rate: ");
            myWorker.HourlyPay = decimal.Parse(Console.ReadLine());

            // Consume the next line for appearance
            Console.WriteLine("");

            // Get the worker's monthly fixed bonus
            Console.Write("Enter the worker's monthly fixed bonus: ");
            myWorker.MonthlyBonus = decimal.Parse(Console.ReadLine());

            // Consume the next line for appearance
            Console.WriteLine("");

            // Get the worker's required training hours
            Console.Write("Enter the worker's required training hours: ");
            myWorker.RequiredTrainingHours = int.Parse(Console.ReadLine());

            // Consume the next line for appearance
            Console.WriteLine("");

            // Get the worker's completed training hours
            Console.Write("Enter the worker's completed training hours: ");
            myWorker.CompletedTrainingHours = int.Parse(Console.ReadLine());

            // Consume the next line for appearance
            Console.WriteLine("");

            return myWorker;

        }
        
        static int GetShiftNumber()
        {
            // Local variables
            string input = null;
            int shiftNumber = 0;

            do
            {
                // Get the worker's shift number
                Console.WriteLine("1. Day Shift");
                Console.WriteLine("2. Night Shift");
                Console.Write("Enter 1 or 2 to choose the worker's shift number: ");
                input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        shiftNumber = 1;
                        break;
                    case "2":
                        shiftNumber = 2;
                        break;
                    default:
                        Console.WriteLine("ERROR: You must enter 1 or 2 to select a shift number.");
                        shiftNumber = 0;
                        // Consume the next line for appearance
                        Console.WriteLine("");
                        break;
                }
            } while (shiftNumber == 0);

            return shiftNumber;
        }

        static void DisplayTeamLeader(TeamLeader myWorker)
        {
            switch (myWorker.ShiftNumber)
            {
                case 1:
                    Console.WriteLine($"Name: {myWorker.EmployeeName}");
                    Console.WriteLine($"Employee Number: {myWorker.EmployeeNumber}");
                    Console.WriteLine($"Shift: Day");
                    Console.WriteLine($"Hourly Pay Rate: ${myWorker.HourlyPay.ToString("n2")}");
                    Console.WriteLine($"Monthly Fixed Bonus: ${myWorker.MonthlyBonus.ToString("n2")}");
                    Console.WriteLine($"Required Training Hours: {myWorker.RequiredTrainingHours}");
                    Console.WriteLine($"Completed Training Hours: {myWorker.CompletedTrainingHours}");
                    break;
                case 2:
                    Console.WriteLine($"Name: {myWorker.EmployeeName}");
                    Console.WriteLine($"Employee Number: {myWorker.EmployeeNumber}");
                    Console.WriteLine($"Shift: Night");
                    Console.WriteLine($"Hourly Pay Rate: ${myWorker.HourlyPay.ToString("n2")}");
                    Console.WriteLine($"Monthly Fixed Bonus: ${myWorker.MonthlyBonus.ToString("n2")}");
                    Console.WriteLine($"Required Training Hours: {myWorker.RequiredTrainingHours}");
                    Console.WriteLine($"Completed Training Hours: {myWorker.CompletedTrainingHours}");
                    break;
            }

            // Consume the next line for appearance
            Console.WriteLine("");
        }
    }
}
