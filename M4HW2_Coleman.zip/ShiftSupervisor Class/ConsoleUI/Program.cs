﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLibrary;
/**
* 11/01/19
* CSC 253
* Kevin Coleman
* This program collects and displays shift supervisor information.
*/
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            // Local variables
            string inputString = null;
            ShiftSupervisor mySupervisor = new ShiftSupervisor(null, 0, 0m, 0m);
            bool run = true;

            // Dispaly the program description to the user.
            Console.WriteLine("This program collects and displays shift supervisor information.");

            do
            {
                // Consume the next line for appearance
                Console.WriteLine("");

                // Display the main menu
                Console.WriteLine("1. Add and display a new shift supervisor");
                Console.WriteLine("2. Exit");

                // Get the user's input to select an option.
                Console.Write("Enter a number to select an option: ");
                inputString = Console.ReadLine();

                // Consume the next line for appearance
                Console.WriteLine("");

                // Execute the program
                switch (inputString)
                {
                    case "1":
                        mySupervisor = GetShiftSupervisor(mySupervisor);
                        DisplayShiftSupervisor(mySupervisor);
                        break;
                    case "2":
                        run = false;
                        break;
                    default:
                        Console.WriteLine("ERROR: You must enter 1 or 2 to select an action.");
                        break;
                }
            } while (run == true);
        }

        static ShiftSupervisor GetShiftSupervisor(ShiftSupervisor mySupervisor)
        {
            // Get the shift supervisor's name
            Console.Write("Enter the shift supervisor's name: ");
            mySupervisor.EmployeeName = Console.ReadLine();

            // Consume the next line for appearance
            Console.WriteLine("");

            // Get the shift supervisor's employee number
            Console.Write("Enter the shift supervisor's employee number: ");
            mySupervisor.EmployeeNumber = int.Parse(Console.ReadLine());

            // Consume the next line for appearance
            Console.WriteLine("");

            // Get the shift supervisor's annual salary
            Console.Write("Enter the shift supervisor's annual salary: ");
            mySupervisor.AnnualSalary = decimal.Parse(Console.ReadLine());

            // Consume the next line for appearance
            Console.WriteLine("");

            // Get the shift supervisor's annual bonus
            Console.Write("Enter the shift supervisor's annual bonus: ");
            mySupervisor.AnnualBonus = decimal.Parse(Console.ReadLine());

            // Consume the next line for appearance
            Console.WriteLine("");

            return mySupervisor;
        }

        static void DisplayShiftSupervisor(ShiftSupervisor mySupervisor)
        {
            Console.WriteLine($"Name: {mySupervisor.EmployeeName}");
            Console.WriteLine($"Employee Number: {mySupervisor.EmployeeNumber}");
            Console.WriteLine($"Annual Salary: ${mySupervisor.AnnualSalary.ToString("n2")}");
            Console.WriteLine($"Annual Bonus: ${mySupervisor.AnnualBonus.ToString("n2")}");

            // Consume the next line for appearance
            Console.WriteLine("");
        }
    }
}
