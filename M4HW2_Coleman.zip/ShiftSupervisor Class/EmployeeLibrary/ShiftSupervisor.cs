﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class ShiftSupervisor : Employee
    {
        // Constructor
        public ShiftSupervisor(string employeeName, int employeeNumber,
            decimal annualSalary, decimal annualBonus) : base(employeeName, employeeNumber)
        {
            AnnualSalary = annualSalary;
            AnnualBonus = annualBonus;
        }

        // AnnualSalary property
        public decimal AnnualSalary { get; set; }

        // AnnualBonus property
        public decimal AnnualBonus { get; set; }
    }
}
