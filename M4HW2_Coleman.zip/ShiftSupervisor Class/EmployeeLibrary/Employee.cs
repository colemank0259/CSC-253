﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Employee
    {
        // Constructor
        public Employee(string employeeName, int employeeNumber)
        {
            EmployeeName = employeeName;
            EmployeeNumber = employeeNumber;
        }

        // EmployeeName property
        public string EmployeeName { get; set; }

        // EmployeeNumber property
        public int EmployeeNumber { get; set; }
    }
}
