﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 09/15/19
* CSC 253
* Group 4
* This program is a dungeon crawl game.
*/
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do
            {
                // Ask user to either run the program or exit
                Console.WriteLine("1. Run the program");
                Console.WriteLine("2. Exit");
                Console.Write("Enter 1 or 2 to select: ");

                // Declare varible to hold user input
                string input = Console.ReadLine();

                if (input == "1")
                {
                    // Local variables
                    char[] delim = { ',' };
                    string roomString = "Mayor's Office,Sewers,Robot Factory,Genetics Lab,Rooftop";
                    string[] rooms = roomString.Split(delim);
                    string weaponString = "Energy Blaster,Power Gauntlets,Sonic Cannon,Pulse Blade";
                    string[] weapons = weaponString.Split(delim);
                    string potionString = "Health,Ability Boost";
                    string[] potions = potionString.Split(delim);
                    string treasureString = "Evidence of Alter Ego,Proof of Criminal Activity,Stolen Goods";
                    string[] treasures = treasureString.Split(delim);
                    List<string> items = new List<string>() {"Disguise", "Office Lunch", "Key Card", "ID Card"};
                    List<string> mobs = new List<string>() {"Robots,Police,Mutant Dogs,Gang Members,Supervillains"};

                    // Display description of the program
                    Console.WriteLine("This program is a dungeon crawl game.");

                    // Consume the next line for appearance
                    Console.WriteLine("");

                    // Display the contents of the rooms array
                    Console.WriteLine("Rooms:");

                    foreach (string room in rooms)
                    {
                        Console.WriteLine(room);
                    }
                    Console.WriteLine("");

                    // Display the contents of the weapons array
                    Console.WriteLine("Weapons:");

                    foreach (string weapon in weapons)
                    {
                        Console.WriteLine(weapon);
                    }
                    Console.WriteLine("");

                    // Display the contents of the potions array
                    Console.WriteLine("Potions:");

                    foreach (string potion in potions)
                    {
                        Console.WriteLine(potion);
                    }
                    Console.WriteLine("");

                    // Display the contents of the treasures array
                    Console.WriteLine("Treasures:");

                    foreach (string treasure in treasures)
                    {
                        Console.WriteLine(treasure);
                    }
                    Console.WriteLine("");

                    // Display the contents of the items list
                    Console.WriteLine("Items:");

                    foreach (string item in items)
                    {
                        Console.WriteLine(item);
                    }
                    Console.WriteLine("");

                    // Display the contents of the mobs list
                    Console.WriteLine("Mobs:");

                    foreach (string mob in mobs)
                    {
                        Console.WriteLine(mob);
                    }
                    Console.WriteLine("");
                }
                else if (input == "2")
                {
                    exit = true;
                }
                else
                {
                    Console.WriteLine("ERROR: You must enter 1 or 2.");
                }

            } while (exit == false);
        }
    }
}
